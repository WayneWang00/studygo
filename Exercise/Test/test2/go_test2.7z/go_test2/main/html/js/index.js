/*
* @Author: name
* @Date:   2018-09-19 11:19:40
* @Last Modified by:   AmyGuo
* @Last Modified time: 2018-09-19 12:02:26
*/
// window.onload = function(){
//     alert("写给怎么在HTML页面中引用JS,CSS文件? 麻烦写个具体代码");
// };