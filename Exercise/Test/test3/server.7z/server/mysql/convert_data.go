package mysql

import (
//"../room"
//"time"
)

//type User struct {
//	Uid        int
//	Name       string
//	Sex        int8 // 0:unknown 1:man 2:woman
//	Url        string
//	Title      string
//	LoginTime  time.Time
//	LogoutTime time.Time
//	TotalTime  int
//	Status     uint8
//}

//type UserInfo struct {
//	Uid           int
//	UserName      string
//	PassWord      string
//	HeadPhoto     string
//	Status        string
//	OnlineTime    int
//	OfflineTime   string
//	DefaultRoomId int
//}

//func ConvertSqlUserInfoToSvrUser(userInfo *UserInfo) (user *User) {
//
//	user.Uid = userInfo.Uid
//	user.Name = userInfo.UserName
//	user.TotalTime = userInfo.OnlineTime
//	user.Password = userInfo.PassWord
//	user.Rid = userInfo.DefaultRoomId
//	return user
//}
